package com.virtusa.sowdetails.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.virtusa.sowdetails.models.SowMasterModel;
import com.virtusa.sowdetails.repositories.SowMasterRepository;

@Service
public class SowMasterService {
	@Autowired
	private SowMasterRepository sowRepo;

	public void setRepository(SowMasterRepository repository) {
		this.sowRepo = repository;
	}
	

	// insert the sowMasterDetails
	public SowMasterModel saveDetails(@RequestBody SowMasterModel sowMasterModel) {
		sowMasterModel = sowRepo.save(sowMasterModel);

		return sowMasterModel;
	}
	

	// get the sowmasterDetails
	public List<SowMasterModel> getAllDetails() {

		return sowRepo.findAll();

	}
	

	// get the sowmasterDetails based on sowid
	public Optional<SowMasterModel> getDetails(@PathVariable String sowid) {

		return sowRepo.findById(Long.parseLong(sowid));

	}
		
	

		// get the sowmasterDetails based on status
		public List<SowMasterModel> getDetailsByStatus(@PathVariable String status) {

			return sowRepo.findByStatus(status);

		}

		
	
	 // delete the sowmasterDetails based on sowid
	public void getDelete(@PathVariable String sowid) {
        
		sowRepo.deleteById(Long.parseLong(sowid));
		System.out.print("single record deleted");		
	}

	
	 
	  // delete all the sowmasterdetails
	public void getAllDelete() {
        
		sowRepo.deleteAll();
		System.out.print(" multiple records deleted");		
	}
	 	
	
	// update single row detail

	public SowMasterModel updateDetails(@RequestBody SowMasterModel sowMasterModel) {

		SowMasterModel exmaster = sowRepo.findById(sowMasterModel.getSowId()).orElse(null);

		exmaster.setStatus(sowMasterModel.getStatus());
		exmaster.setCitiSowOwnerName(sowMasterModel.getCitiSowOwnerName());
		exmaster.setCitiSowOwnerEmailId(sowMasterModel.getCitiSowOwnerEmailId());
		exmaster.setVirtusaPMName(sowMasterModel.getVirtusaPMName());
		exmaster.setVirtusaPMEmailId(sowMasterModel.getVirtusaPMEmailId());
		return sowRepo.save(exmaster);
	}

	// update Multiple sowMasterDetails
	/*public void updateMultipleRowDetails(@RequestBody List<SowMasterModel> sowMasterModel) {

			for(SowMasterModel model:sowMasterModel)
			{
				repository.update(model.getSowId(),model.getStatus(),model.getTenure(),model.getCitiSowOwnerName(),
						model.getCitiSowOwnerEmailId(),
						,model.getVirtusaPMName(),model.getVirtusaPMEmailId());
			}
		}*/

	/*	// get the sowmasterDetails based on sector
	public List<SowMasterModel> getDetailsBySector(@PathVariable String sector) {

		return sowRepo.findBySector(sector);

	}*/

	
}
