package com.virtusa.sowdetails.testcontroller;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.xml.ws.Response;

import org.apache.coyote.http11.Http11AprProtocol;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.virtusa.sowdetails.controllers.SowUploadController;
import com.virtusa.sowdetails.controllers.SowViewController;
import com.virtusa.sowdetails.models.SowMasterModel;
import com.virtusa.sowdetails.repositories.SowMasterRepository;
import com.virtusa.sowdetails.services.SowMasterService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = SowViewController.class)
public class SowMasterControllerTest {
	
	/*@Test
	public void test() {
		fail("Not yet implemented");
	}*/
		
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private SowMasterService sowMasterService;
	
	@MockBean
	private SowMasterRepository sowRepo;
	
	
	List<SowMasterModel> mockSowList= new ArrayList<SowMasterModel>();
	
	SowMasterModel mocksow = new SowMasterModel(233l, "sOW_Con_Id233", "sOW_Con_Pred_Id233", "Gov",  LocalDate.of(2015,3,19),
			LocalDate.of(2015,3,19),  LocalDate.of(2015,3,19), 10, "fG_Id233", "data233", "y",
			54l, "geographymumbai", 57l, 87l, "areamumbai", 34l,
			"Vishal", "vishal@citi.com", "viraj", "viraj@citi.com", "vaibhav", "vibhav@virtusa.com",
			"y",  LocalDate.of(2015,3,19), 20,"y",
			"best",  LocalDate.of(2015,3,19), "virat", LocalDate.of(2015,3,19), "shreyas");
	
	Optional<SowMasterModel>sowModel1=Optional.of(new SowMasterModel(233l, "sOW_Con_Id233", "sOW_Con_Pred_Id233", "Gov",  LocalDate.of(2013,1,1),
			LocalDate.of(2013,1,1),  LocalDate.of(2013,1,1), 10, "fG_Id233", "data233", "y",
			54l, "geographymumbai", 57l, 87l, "areamumbai", 34l,
			"Vishal", "vishal@citi.com", "viraj", "viraj@citi.com", "vaibhav", "vibhav@virtusa.com",
			"y",  LocalDate.of(2013,1,1), 20,"y",
			"best",  LocalDate.of(2013,1,1), "virat", LocalDate.of(2013,1,1), "chahal"));
	
	
	
	
	String mockJsonSowString= "{\"sowId\":233,\"sOW_Contract_Id\":\"sOW_Con_Id233\",\"sOW_Contract_Pred_Id\":\"sOW_Con_Pred_Id233\",\"contractName\":\"Gov\",\"signedEffectiveDate\":\"2015-03-19\",\"sow_Strart_Date\":\"2015-03-19\",\"sow_End_Date\":\"2015-03-19\",\"tenure\":10,\"fG_Id\":\"fG_Id233\",\"source_Data\":\"data233\",\"status\":\"y\",\"auroraCitiLegalEntitySeqFk\":54,\"geography\":\"geographymumbai\",\"auroraServiceTypeSeqFk\":57,\"auroraSectorTypeSeqFk\":87,\"area\":\"areamumbai\",\"auroraBusinessUnitSeqFk\":34,\"citiSowOwnerName\":\"Vishal\",\"citiSowOwnerEmailId\":\"vishal@citi.com\",\"citiPM\":\"viraj\",\"citiPMEmailId\":\"viraj@citi.com\",\"virtusaPMName\":\"vaibhav\",\"virtusaPMEmailId\":\"vibhav@virtusa.com\",\"autoEmailTriggeredFlag\":\"y\",\"autoEmailTriggeredDate\":\"2015-03-19\",\"keyPersonnelSOWCount\":20,\"cobApplicability\":\"y\",\"remarks\":\"best\",\"createdDate\":\"2015-03-19\",\"createdBy\":\"virat\",\"modifiedDate\":\"2015-03-19\",\"modifiedBy\" :\"shreyas\"}";
	
	
	
	
	@Test
	public void testAddSowData() throws Exception {
		RequestBuilder requestBuilder=MockMvcRequestBuilders.post("/api/citi-portal/sow-details").accept(MediaType.APPLICATION_JSON).content(mockJsonSowString)
				.contentType(MediaType.APPLICATION_JSON);
		MvcResult result=mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response=result.getResponse();
		assertEquals(HttpStatus.OK.value(), response.getStatus());
		
		
		
	}
	
	
	@Test
	public void testGetdata() throws Exception {
		mockSowList.add(mocksow);
		Mockito.when(sowMasterService.getAllDetails()).thenReturn(mockSowList);
		RequestBuilder requestBuilder=MockMvcRequestBuilders.get("/api/citi-portal/sow-details").accept(MediaType.APPLICATION_JSON);
		MvcResult result=mockMvc.perform(requestBuilder).andReturn();	
		//System.out.println(result.getResponse().getContentAsString());
		
		String expected="[{\"sowId\":233,\"contractName\":\"Gov\",\"signedEffectiveDate\":\"2015-03-19\",\"tenure\":10,\"status\":\"y\",\"auroraCitiLegalEntitySeqFk\":54,\"geography\":\"geographymumbai\",\"auroraServiceTypeSeqFk\":57,\"auroraSectorTypeSeqFk\":87,\"area\":\"areamumbai\",\"auroraBusinessUnitSeqFk\":34,\"citiSowOwnerName\":\"Vishal\",\"citiSowOwnerEmailId\":\"vishal@citi.com\",\"citiPM\":\"viraj\",\"citiPMEmailId\":\"viraj@citi.com\",\"virtusaPMName\":\"vaibhav\",\"virtusaPMEmailId\":\"vibhav@virtusa.com\",\"autoEmailTriggeredFlag\":\"y\",\"autoEmailTriggeredDate\":\"2015-03-19\",\"keyPersonnelSOWCount\":20,\"cobApplicability\":\"y\",\"remarks\":\"best\",\"createdDate\":\"2015-03-19\",\"createdBy\":\"virat\",\"modifiedDate\":\"2015-03-19\",\"modifiedBy\":\"shreyas\",\"deleted\":false,\"sow_Strart_Date\":\"2015-03-19\",\"sow_Contract_Pred_Id\":\"sOW_Con_Pred_Id233\",\"sow_Contract_Id\":\"sOW_Con_Id233\",\"sow_End_Date\":\"2015-03-19\",\"source_Data\":\"data233\",\"fg_Id\":\"fG_Id233\"}]";
 		JSONAssert.assertEquals(expected,result.getResponse().getContentAsString(), false);
		
		
		
		
	}
	
	
	
	
	@Test
	public void testUpdateSowData() throws Exception {
		RequestBuilder requestBuilder=MockMvcRequestBuilders.put("/api/citi-portal/sow-details").accept(MediaType.APPLICATION_JSON).content(mockJsonSowString)
				.contentType(MediaType.APPLICATION_JSON);
		MvcResult result=mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response=result.getResponse();
		assertEquals(HttpStatus.OK.value(), response.getStatus());
		
		
	}
	
	 @Test
	public void testDeleteAllSowData() throws Exception {
		RequestBuilder requestBuilder=MockMvcRequestBuilders.delete("/api/citi-portal/sow-details").accept(MediaType.APPLICATION_JSON).content(mockJsonSowString)
				.contentType(MediaType.APPLICATION_JSON);
		MvcResult result=mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response=result.getResponse();
		assertEquals(HttpStatus.OK.value(), response.getStatus());
		
		
	}
	
	
	
	
	/*	@Test
	public void testGetDataByID() throws Exception{
		String sowid="233";
		mockSowList.add(mocksow);
		//long sowid=23l;
		//String id=Long.toString(sowid);
		Mockito.when(sowMasterService.getDetails(sowid)).thenReturn(sowModel1);
		RequestBuilder requestBuilder=MockMvcRequestBuilders.get("/api/citi-portal/sow-details/{sowId}").accept(MediaType.APPLICATION_JSON);
		MvcResult result=mockMvc.perform(requestBuilder).andReturn();	
		System.out.println(result.getResponse().getContentAsString());
		
		
				//MockHttpServletResponse response=result.getResponse();
		//assertEquals(HttpStatus.OK.value(), response.getStatus());
		
		
	}*/

	

	
	

}
