package com.virtusa.sowdetails.testcontroller;

import static org.junit.Assert.*;

import java.io.InputStream;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
/*
import com.virtusa.sowdetails.controllers.SowUploadController;
import com.virtusa.sowdetails.services.SowUploadService;
import org.junit.Assert;
//import junit.framework.Assert;
@RunWith(MockitoJUnitRunner.class)
//@RunWith(SpringRunner.class)
public class SowUploadControllerTest {
	 private InputStream is;
	 private MockMvc mockMvc;
	 @Mock
	 private SowUploadService sowUploadService;
	 @Spy
	 @InjectMocks
	 private SowUploadController controller = new SowUploadController();
	 @Before
	 public void init() {
		 mockMvc=MockMvcBuilders.standaloneSetup(controller).build();
		 is=controller.getClass().getClassLoader().getResourceAsStream("tempfile.xlsx");
				 				 
	 }
	 
	 @Test
	 public void testUploadFile()throws Exception{
		 MockMultipartFile mockMultipartFile = new MockMultipartFile("file","tempfile.xlsx","multipart/form-data", is);
		 MvcResult result = mockMvc.perform(MockMvcRequestBuilders.multipart("/uploadFile").file(mockMultipartFile).
				            contentType(MediaType.MULTIPART_FORM_DATA))
				 .andExpect(MockMvcResultMatchers.status().is(200)).andReturn();
		
		 Assert.assertEquals(200, result.getResponse().getStatus());
		 Assert.assertNotNull(result.getResponse().getContentAsString());
		 Assert.assertEquals("tempfile.xlsx", result.getResponse().getContentAsString());
		 
		
	 }

}
*/

