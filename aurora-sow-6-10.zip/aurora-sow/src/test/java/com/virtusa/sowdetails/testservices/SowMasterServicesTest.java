package com.virtusa.sowdetails.testservices;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.sql.Date;
import java.time.LocalDate;

import org.junit.Test;
//import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.virtusa.sowdetails.models.SowMasterModel;
import com.virtusa.sowdetails.repositories.SowMasterRepository;
import com.virtusa.sowdetails.services.SowMasterService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SowMasterServicesTest {
	
	@Autowired
	private SowMasterService sowMasterService;
	 
	@MockBean
	private SowMasterRepository sowRepo;
	
	
	
	//Testing for getting all information function
	@Test
	public void getAllDetailsTest() {
		when(sowRepo.findAll())
		.thenReturn(Stream
				.of(new SowMasterModel(23l, "sOW_Cont_Id23", "sOW_Con_Pred_Id23", "Gov",  LocalDate.of(2013,1,1),
						LocalDate.of(2013,1,1),  LocalDate.of(2013,1,1), 10, "fG_23", "Data", "y",
						54l, "geographypune", 57l, 87l, "areapune", 34l,
						"Aditya", "adityasharma@gmail.com", "pari", "pari@citi.com", "Arvind", "arvind@virtisa.com",
						"y",  LocalDate.of(2013,1,1), 20,"y",
						"good",  LocalDate.of(2013,1,1), "avi", LocalDate.of(2013,1,1),"ravi"),
						new SowMasterModel(233l, "sOW_Con_Id233", "sOW_Con_Pred_Id233", "Gov",  LocalDate.of(2013,1,1),
								LocalDate.of(2013,1,1),  LocalDate.of(2013,1,1), 10, "fG_Id233", "data233", "y",
								54l, "geographymumbai", 57l, 87l, "areamumbai", 34l,
								"Vishal", "vishal@citi.com", "viraj", "viraj@citi.com", "vaibhav", "vibhav@virtusa.com",
								"y",  LocalDate.of(2013,1,1), 20,"y",
								"best",  LocalDate.of(2013,1,1), "virat", LocalDate.of(2013,1,1), "chahal"))
				.collect(Collectors.toList()));
	    assertEquals(2,sowMasterService.getAllDetails().size() );


		
	}
	
	//test function for getting information based on the status
	
	@Test
	public void getDetailsByStatusTest() {
		
		String status="y";
		when(sowRepo.findByStatus(status))
		.thenReturn(Stream
				.of(new SowMasterModel(233l, "sOW_Con_Id233", "sOW_Con_Pred_Id233", "Gov",  LocalDate.of(2013,1,1),
						LocalDate.of(2013,1,1),  LocalDate.of(2013,1,1), 10, "fG_Id233", "data233", "y",
						54l, "geographymumbai", 57l, 87l, "areamumbai", 34l,
						"Vishal", "vishal@citi.com", "viraj", "viraj@citi.com", "vaibhav", "vibhav@virtusa.com",
						"y",  LocalDate.of(2013,1,1), 20,"y",
						"best",  LocalDate.of(2013,1,1), "virat", LocalDate.of(2013,1,1), "chahal"))
				.collect(Collectors.toList()));
		assertEquals(1, sowMasterService.getDetailsByStatus(status).size());
		
		
	}
	
		// test function for getting information based on the sowid
	@Test
	public void getDetailsTest() {
		String sowid="147";
		
		Optional<SowMasterModel>sowModelById=Optional.of(new SowMasterModel(233l, "sOW_Con_Id233", "sOW_Con_Pred_Id233", "Gov", 
				LocalDate.of(2013,1,1),
				LocalDate.of(2013,1,1),  LocalDate.of(2013,1,1), 10, "fG_Id233", "data233", "y",
				54l, "geographymumbai", 57l, 87l, "areamumbai", 34l,
				"Vishal", "vishal@citi.com", "viraj", "viraj@citi.com", "vaibhav", "vibhav@virtusa.com",
				"y",  LocalDate.of(2013,1,1), 20,"y",
				"best",  LocalDate.of(2013,1,1), "virat", LocalDate.of(2013,1,1), "chahal"));
		
		when(sowRepo.findById(Long.parseLong(sowid))).thenReturn(sowModelById);
	  assertEquals(sowModelById,sowModelById);
		
	}
	
	// test function for saving new sow model
	
	@Test
	public void saveDetailsTest()
	{
		SowMasterModel sowMasterModel= new SowMasterModel(233l, "sOW_Con_Id233", "sOW_Con_Pred_Id233", "Gov",  LocalDate.of(2013,1,1),
				LocalDate.of(2013,1,1),  LocalDate.of(2013,1,1), 10, "fG_Id233", "data233", "y",
				54l, "geographymumbai", 57l, 87l, "areamumbai", 34l,
				"Vishal", "vishal@citi.com", "viraj", "viraj@citi.com", "vaibhav", "vibhav@virtusa.com",
				"y",  LocalDate.of(2013,1,1), 20,"y",
				"best",  LocalDate.of(2013,1,1), "virat", LocalDate.of(2013,1,1), "chahal");
		      when(sowRepo.save(sowMasterModel)).thenReturn(sowMasterModel);
		      assertEquals(sowMasterModel, sowMasterService.saveDetails(sowMasterModel));
		      
		      				
		
	}
	
	
	// test function for delete the model
	@Test
	public void getDeleteTest()
	{
		String sowid="47";
		SowMasterModel sowMasterModel= new SowMasterModel(233l, "sOW_Con_Id233", "sOW_Con_Pred_Id233", "Gov",  LocalDate.of(2013,1,1),
				LocalDate.of(2013,1,1),  LocalDate.of(2013,1,1), 10, "fG_Id233", "data233", "y",
				54l, "geographymumbai", 57l, 87l, "areamumbai", 34l,
				"Vishal", "vishal@citi.com", "viraj", "viraj@citi.com", "vaibhav", "vibhav@virtusa.com",
				"y",  LocalDate.of(2013,1,1), 20,"y",
				"best",  LocalDate.of(2013,1,1), "virat", LocalDate.of(2013,1,1), "chahal");
		      sowMasterService.getDelete(sowid);
		      verify(sowRepo,times(1)).deleteById(Long.parseLong(sowid));
		
	}
	//delete all function with one Record
	
	@Test
	public void getAllDeleteTest() {
		SowMasterModel sowMasterModel= new SowMasterModel(233l, "sOW_Con_Id233", "sOW_Con_Pred_Id233", "Gov",  LocalDate.of(2013,1,1),
				LocalDate.of(2013,1,1),  LocalDate.of(2013,1,1), 10, "fG_Id233", "data233", "y",
				54l, "geographymumbai", 57l, 87l, "areamumbai", 34l,
				"Vishal", "vishal@citi.com", "viraj", "viraj@citi.com", "vaibhav", "vibhav@virtusa.com",
				"y",  LocalDate.of(2013,1,1), 20,"y",
				"best",  LocalDate.of(2013,1,1), "virat", LocalDate.of(2013,1,1), "chahal");		
		sowMasterService.getAllDelete();
		verify(sowRepo,times(1)).deleteAll();
				
		
	}
	
	
	
//delete all function with multiple record
	
	@Test
	public void getAllDeleteTest2() {
		SowMasterModel sowMasterModel= new SowMasterModel(147l, "sOW_Contract_Id147", "sOW_Contract_Pred_Id147", "contractName147",  LocalDate.of(2013,1,1),
				LocalDate.of(2013,1,1),  LocalDate.of(2013,1,1), 10, "fG_Id147", "source_Data147", "n",
				540l, "pune", 507l, 807l, "areapunemumbai", 324l,
				"pradip", "pradip@gmail.com", "citiPMsamir", "citiPMsamirpatil", "amol", "amol@gmail.com",
				"y",  LocalDate.of(2013,1,1), 20,"y",
				"remarks213",  LocalDate.of(2013,1,1), "deepika", LocalDate.of(2013,1,1), "salman");
		
		SowMasterModel sowMasterModel2= new SowMasterModel(632l, "sOW_Contract_Id147", "sOW_Contract_Pred_Id147", "contractName147", 
				LocalDate.of(2013,1,1),
				LocalDate.of(2013,1,1),  LocalDate.of(2013,1,1), 10, "fG_Id147", "source_Data147", "n",
				540l, "pune", 507l, 807l, "areapunemumbai", 324l,
				"pradip", "pradip@gmail.com", "citiPMsamir", "citiPMsamirpatil", "amol", "amol@gmail.com",
				"y",  LocalDate.of(2013,1,1), 20,"y",
				"remarks213",  LocalDate.of(2013,1,1), "deepika", LocalDate.of(2013,1,1), "salman");
				
		
		sowMasterService.getAllDelete();
		verify(sowRepo,times(1)).deleteAll();			
		
	}
	
	//update data
	
	@Test
	public void updateDetailsTest() {
		
		Optional<SowMasterModel>sowModel=Optional.of(new SowMasterModel(147l, "sOW_Contract_Id147", "sOW_Contract_Pred_Id147", "contractName147",  LocalDate.of(2013,1,1),
				LocalDate.of(2013,1,1),  LocalDate.of(2013,1,1), 10, "fG_Id147", "source_Data147", "n",
				540l, "pune", 507l, 807l, "areapunemumbai", 324l,
				"pradip", "pradip@gmail.com", "citiPMsamir", "citiPMsamirpatil", "amol", "amol@gmail.com",
				"y",  LocalDate.of(2013,1,1), 20,"y",
				"remarks213",  LocalDate.of(2013,1,1), "deepika", LocalDate.of(2013,1,1), "salman"));
		
		when(sowRepo.findById(ArgumentMatchers.anyLong())).thenReturn(sowModel);
		
		when(sowRepo.save(sowModel.get())).thenReturn(new SowMasterModel(147l, "sOW_Contract_Id147", "sOW_Contract_Pred_Id147", "contractName147",  LocalDate.of(2013,1,1),
				LocalDate.of(2013,1,1),  LocalDate.of(2013,1,1), 10, "fG_Id147", "source_Data147", "n",
				540l, "pune", 507l, 807l, "areapunemumbai", 324l,
				"pradip", "pradip@gmail.com", "citiPMsamir", "citiPMsamirpatil", "amol", "amol@gmail.com",
				"y",  LocalDate.of(2013,1,1), 20,"y",
				"remarks213",  LocalDate.of(2013,1,1), "Shradhha", LocalDate.of(2013,1,1), "shahrukh"));
		
		     assertEquals(sowModel, sowModel);
		
	
		
	}
	
	

}
