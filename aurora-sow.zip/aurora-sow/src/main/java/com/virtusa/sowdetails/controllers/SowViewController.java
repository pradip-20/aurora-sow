package com.virtusa.sowdetails.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.sowdetails.models.SowMasterModel;
import com.virtusa.sowdetails.services.SowMasterService;

@RestController
@RequestMapping("/api/citi-portal")
public class SowViewController {

	@Autowired
	private SowMasterService sowMasterService;

	// Adding the sowMaster details
	public void setSowMasterService(SowMasterService sowMasterService) {
		this.sowMasterService = sowMasterService;
	}

	@CrossOrigin("*")
	@PostMapping("/addDetails")
	public @ResponseBody SowMasterModel addSowMasterDetails(@RequestBody SowMasterModel model) {
		return this.sowMasterService.saveDetails(model);
	}
	// Viewing the sowmaster details

	@CrossOrigin("*")
	@GetMapping(path = "/getDetails", produces = "application/json")
	public List<SowMasterModel> getSowMasterDetails() {
		return this.sowMasterService.getAllDetails();
	}

	// Viewing the sowmaster details based on sowid
	@GetMapping("/getDetailsByID/{sowId}")
	public @ResponseBody Optional<SowMasterModel> getSowMasterDetailsById(@PathVariable String sowId) {
		return this.sowMasterService.getDetails(sowId);
	}

	// Viewing the sowmaster details based on sector
	@GetMapping("/getDetailsBySector/{sector}")
	public @ResponseBody List<SowMasterModel> getSowMasterDetailsBySector(@PathVariable String sector) {
		System.out.println(sector);
		return this.sowMasterService.getDetailsBySector(sector);
	}

	// Viewing the sowmaster details based on status
	@GetMapping("/getDetailsByStatus/{status}")
	public @ResponseBody List<SowMasterModel> getSowMasterDetailsByStatus(@PathVariable String status) {
		System.out.println(status);
		return this.sowMasterService.getDetailsByStatus(status);
	}

	// update single record
	@CrossOrigin("*")
	@PutMapping("/updateDetails")
	public SowMasterModel updateSowMasterDetails(@RequestBody SowMasterModel model) {
		System.out.println(model.toString());
		return this.sowMasterService.updateDetails(model);
	}

	// update Multiple sowMasterDetails
	/*@CrossOrigin("*")
	@PutMapping("/updateBulkDetails")
	public void getMultipleRowDetails(@RequestBody List<SowMasterModel> sowMasterModel) {
		System.out.println("- - - - - - - - - - - - - - - "+ sowMasterModel.get(0).toString());
		this.sowMasterService.updateMultipleRowDetails(sowMasterModel);
	}*/

}
