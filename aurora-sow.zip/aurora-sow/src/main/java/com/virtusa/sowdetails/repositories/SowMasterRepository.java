package com.virtusa.sowdetails.repositories;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.virtusa.sowdetails.models.SowMasterModel;

@Repository
public interface SowMasterRepository extends JpaRepository<SowMasterModel, Long> {

	@Query(value = "select * from sowmaster_details s where s.Sector=:sector", nativeQuery = true)
	List<SowMasterModel> findBySector(@PathVariable("sector") String sector);

	@Query(value = "select * from sowmaster_details s where s.Status=:status", nativeQuery = true)
	List<SowMasterModel> findByStatus(@PathVariable("status") String status);

	@Modifying
	@Transactional
	@Query(value = "update sowmaster_details s set s.Status=:status,s.Tenure=:tenure,s.Expiry_Date=:expiryDate,s.Sow_Executing_Location=:sowExecutingLocation,s.Citi_SOWOwner_Name=:citiSowOwnerName,s.Citi_SOWOwner_Email_Id=:citiSowOwnerEmailId,s.Citi_Project_Manager=:citiProjectManager,s.Citi_Project_Manager_EmailId=:citiProjectManagerEmailId,s.Virtusa_Segment_Delivery_Head=:virtusaSegmentDeliveryHead,s.Virtusa_DD_Name=:virtusaDDName,s.Virtusa_DD_EmailId=:virtusaDDEmailId,"
			+ "s.Virtusa_PD_Name=:virtusaPDName,s.Virtusa_PD_EmailId=:virtusaPDEmailId,s.Virtusa_PM_Name=:virtusaPMName,s.Virtusa_PM_EmailId=:virtusaPMEmailId where s.SOW_ID=:id", nativeQuery = true)
	void update(@PathVariable("sowId") String id, @PathVariable("status") String status,
			@PathVariable("tenure") int tenure, @PathVariable("expiryDate") LocalDate expiryDate,
			@PathVariable("sowExecutingLocation") String sowExecutingLocation,
			@PathVariable("citiSowOwnerName") String citiSowOwnerName,
			@PathVariable("citiSowOwnerEmailId") String citiSowOwnerEmailId,
			@PathVariable("citiProjectManager") String citiProjectManager,
			@PathVariable("citiProjectManagerEmailId") String citiProjectManagerEmailId,
			@PathVariable("virtusaSegmentDeliveryHead") String virtusaSegmentDeliveryHead,
			@PathVariable("virtusaDDName") String virtusaDDName,
			@PathVariable("virtusaDDEmailId") String virtusaDDEmailId,
			@PathVariable("virtusaPDName") String virtusaPDName,
			@PathVariable("virtusaPDEmailId") String virtusaPDEmailId,
			@PathVariable("virtusaPMName") String virtusaPMName,
			@PathVariable("virtusaPMEmailId") String virtusaPMEmailId);

}
