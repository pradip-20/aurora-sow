package com.virtusa.sowdetails.services;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.virtusa.sowdetails.annotations.SowField;
import com.virtusa.sowdetails.models.SowMasterModel;
import com.virtusa.sowdetails.repositories.SowMasterRepository;

@Service
public class SowUploadService {

	@Autowired
	SowMasterRepository sowRepo;

//	@Autowired
//	SowMaster sowmaster;
// Tightly Coupled

	SowMasterModel sow = new SowMasterModel();

	public String phraseFile(MultipartFile file)
			throws IllegalStateException, IOException /* throws IllegalStateException, IOException */ {

		System.out.println(file.getOriginalFilename());
		File newFile = new File("C:\\Users\\kulka\\tempFile.xslx"); // change it from hardcoded to
		newFile.setReadable(true);
		file.transferTo(newFile);
		try {
			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(newFile);

			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);

			// code get the header map
			Map<Integer, String> headerMap = new HashMap<Integer, String>();
			Row headerRow = sheet.getRow(0);
			short minColumnIndex = headerRow.getFirstCellNum();
			short maxColumnIndex = headerRow.getLastCellNum();
			for (short i = minColumnIndex; i < maxColumnIndex; i++) {
				Cell cell = headerRow.getCell(i);
				headerMap.put((int) i, cell.getStringCellValue());
			}
			// code get the header map ends

			// code to get declared fields in the SOW model class
			Class<?> sowclass = sow.getClass();
			Field[] fields = sowclass.getDeclaredFields();
			for (Field f : fields) {
				f.setAccessible(true);
			}
			// code to get declared fields in the SOW model class

			// Iterate through each rows one by one
			Iterator<Row> rowIterator = sheet.iterator();
			rowIterator.next();
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();

				// For each row, iterate through all the columns
				Iterator<Cell> cellIterator = row.cellIterator();

				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();

					String fieldName = headerMap.get(cell.getColumnIndex()); // find the attribute in the class which
																				// has @SowField with fieldName
					try {
						System.out.println("*** Field : "+fieldName);
						Method sowMethod = getSowMethod(fields, fieldName, sow);
						if(sowMethod != null) {
							if (sowMethod.getParameterTypes()[0].equals(String.class)) {
								sowMethod.invoke(sow, cell.getStringCellValue());
							} else if (sowMethod.getParameterTypes()[0].equals(Integer.class)) {
								Integer l = Integer.parseInt(cell.getStringCellValue());
								sowMethod.invoke(sow, l);
							} else if (sowMethod.getParameterTypes()[0].equals(Long.class)) {
								Long l = Long.parseLong(cell.getStringCellValue());
								sowMethod.invoke(sow, l);
							} else if (sowMethod.getParameterTypes()[0].equals(LocalDate.class)) {
								LocalDate d = cell.getDateCellValue().toInstant().atZone(ZoneId.systemDefault())
										.toLocalDate();
								sowMethod.invoke(sow, d);
							}							
						}
					} catch (IntrospectionException ex) {
						System.out.println("**** "+ex.getLocalizedMessage());
					}
					/*
					 * switch (cell.getColumnIndex()) { case 0:
					 * System.out.println(cell.getNumericCellValue());
					 * sow.setSowId(Double.toString(cell.getNumericCellValue())); break; case 1:
					 * sow.setSowExecutingLocation(cell.toString()); break; }
					 */
					System.out.println(sow.toString());
					
				}
				sowRepo.save(sow);
				System.out.println("");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("SAVED- - - - - - - - - - - - - - - - - - - - -"+LocalDate.now().toString());
		return "Saved";
	}

	public Method getSowMethod(Field[] fields, String fieldName, SowMasterModel sow)
			throws IllegalArgumentException, IllegalAccessException, IntrospectionException {
		for (Field field : fields) {
			if (field.isAnnotationPresent(SowField.class) && fieldName.equals(getAnnotatedValue(field))) {
				String varName = (String) field.getName();
				// String setter = "set"+varName.substring(0,1).toUpperCase() +
				// varName.substring(1);
				//System.out.println("Variable Name : " + varName);
				PropertyDescriptor pd = new PropertyDescriptor(varName, sow.getClass());
				Method setterMethod = pd.getWriteMethod();
				return setterMethod;
			}
		}
		return null;
	}

	private String getAnnotatedValue(Field field) {
		SowField sowAnnotation = field.getAnnotation(SowField.class);
		return (sowAnnotation != null) ? sowAnnotation.col() : "null";
	}

}
