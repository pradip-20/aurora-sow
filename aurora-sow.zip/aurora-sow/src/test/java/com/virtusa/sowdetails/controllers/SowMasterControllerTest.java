package com.virtusa.sowdetails.controllers;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.virtusa.sowdetails.models.SowMasterModel;
import com.virtusa.sowdetails.services.SowMasterService;

@RunWith(MockitoJUnitRunner.class)
public class SowMasterControllerTest {

	@InjectMocks
	SowViewController controller;
	@Mock
	private SowMasterService sowMasterService;
	
	
//	@Before
//	public void setUp() { 
//		MockitoAnnotations.initMocks(this);
//		SowViewController controller = new SowViewController();
//		
//		controller.setSowMasterService(sowMasterService);
//	}
	@Test
	public void addSowMasterDetailsTest() {
		// when(sowMasterService.saveDetails(SowMasterModel)).thenReturn(true);
         
		 SowMasterModel model = new SowMasterModel();
		 model.setArea("area");
		 controller.addSowMasterDetails(model);
	}
	
	@Test
	public void getSowMasterDetailsTest() {
		controller.getSowMasterDetails();
	}
	
	/*@Test
	public void getSowMasterDetailsByIdTest() {
		 SowMasterModel model = new SowMasterModel();
		 model.setSowId((long)1);
		controller.getSowMasterDetailsById(model.getSowId());
	}
	
	@Test
	public void getSowMasterDetailsBySectorTest() {
		 SowMasterModel model = new SowMasterModel();
		 model.setContractName("name");
		controller.getSowMasterDetailsBySector(model.getSector());
	}
	
	@Test
	public void getSowMasterDetailsByStatusTest() {
		 SowMasterModel model = new SowMasterModel();
		 model.setContractName("name");
		controller.getSowMasterDetailsByStatus(model.getStatus());
	}*/

} 