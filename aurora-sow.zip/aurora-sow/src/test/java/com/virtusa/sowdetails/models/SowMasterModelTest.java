package com.virtusa.sowdetails.models;

import java.text.SimpleDateFormat;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class SowMasterModelTest {
	
	@InjectMocks
	SowMasterModel sowMasterModel;
	
	SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd-MM-yy");
	
	
	@Before
	public void setUp() {
		
		sowMasterModel = new SowMasterModel();
		/*sowMasterModel.setArea("Tech");
		sowMasterModel.setBusinessUnit("IM Shared Service - NAM");
		sowMasterModel.setCitiLegalEntity("Citigroup Technology Inc");
		sowMasterModel.setCitiProjectManager("Hari");
		sowMasterModel.setCitiProjectManagerEmailId("hari@citi.com");
		sowMasterModel.setCitiSowOwnerName("carolyn");
		sowMasterModel.setCitiSowOwnerEmailId("carolyn@citi.com");
		//sowMasterModel.setSignedEffectiveDate(simpleDateFormat1.format("20-02-20"));
		sowMasterModel.setContractName("Institutional client");
		sowMasterModel.setContractType("contract");
		sowMasterModel.setGeography("NAM");
		sowMasterModel.setSector("ICG");
		sowMasterModel.setServiceType("service");
		sowMasterModel.setSourceData("FG-SOW");
		sowMasterModel.setSowExecutingLocation("India");
		sowMasterModel.setSowId("T18077");
		sowMasterModel.setStatus("Active");
		sowMasterModel.setTenure(5);
		sowMasterModel.setVirtusaDDEmailId("dd@virtusa.com");
		sowMasterModel.setVirtusaDDName("DD");
		sowMasterModel.setVirtusaPDEmailId("pd@virtusa.com");
		sowMasterModel.setVirtusaPDName("PD");
		sowMasterModel.setVirtusaPMEmailId("pm@virtusa.com");
		sowMasterModel.setVirtusaPMName("PM");
		sowMasterModel.setVirtusaSegmentDeliveryHead("AMER BFS CITI TTS");	*/
	}
	
	
}
